import configparser

CONFIG = configparser.ConfigParser() # configuration file parser
CONFIG.read("recipe.ini") # reading the configuration file
