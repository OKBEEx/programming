import configparser

#creating a config object to read the ini file
CONFIG = configparser.ConfigParser()
CONFIG.read("recipe.ini") #reading the ini file
