import configparser

CONFIG = configparser.ConfigParser()
CONFIG.read("recipe.ini")
