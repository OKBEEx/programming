Before you can use the these apps, make sure you have the requirements installed:  
Windows: `py -m pip install -r requirements.txt`  
Linux: `python3 -m pip install -r requirements.txt`

Also, you have to run "create_db.py" once before running any of the apps.
This will create the database and populate it with some example data.

So, as a checklist, the first time you should:

1. Unzip the .ZIP-archive to an empty directory
2. Go to the directory on the commandline (`cd <dir-name>`)
3. Install a Python Virtual Environment:  
   Windows: `py -m venv .venv`  
   Linux: `python3 -m venv .venv`
4. Activate the VEnv:  
   Windows: `.\.venv\Scripts\activate`  
   Linux: `./.venv/Scripts/activate`
5. Install requirements in the VEnv:  
   Windows: `py -m pip install -r requirements.txt`  
   Linux: `python3 -m pip install -r requirements.txt`
6. Run the create_db script:  
   Windows: `py .\backend\create_db.py`  
   Linux: `python3 ./backend/create_db.py`
7. Start the API server:  
   Windows: `py .\backend\recipe_api.py`  
   Linux: `python3 ./backend/recipe_api.py`

After that, you can start the frontend website with:  
Windows: `py .\frontend\recipe_frontend.py`  
Linux: `python3 ./frontend/recipe_frontend.py`

Or you can start the Command Line Tool with:  
Windows: `py .\cli\recipe_cli.py`  
Linux: `python3 ./cli/recipe_cli.py`
