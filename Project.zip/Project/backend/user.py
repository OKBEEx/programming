import sqlite3

from flask import jsonify

from backend.config import CONFIG

def dict_factory(cursor, row): # function to convert the row to a dictionary
    fields = [ column[0] for column in cursor.description ] # getting the column names
    return {key: value for key, value in zip(fields, row)}

def get_db_connection():
    db_conn = sqlite3.connect(CONFIG["database"]["name"]) # getting the database connection
    db_conn.row_factory = dict_factory
    return db_conn

def read_all(): # function to read all the users
    ALL_USERS = "SELECT * FROM users"
    
    db_conn = get_db_connection()
    cursor = db_conn.cursor() # cursor to execute the query
    cursor.execute(ALL_USERS) # executing the query
    resultset = cursor.fetchall() # fetching all the users
    db_conn.close()

    return jsonify(resultset)

def create(user): # function to create a new user
    INSERT_USER = "INSERT INTO users (first_name, last_name, email, phone, password) VALUES (?, ?, ?, ?, ?)"
    
    db_conn = get_db_connection()
    cursor = db_conn.cursor()
    cursor.execute(INSERT_USER, (user["first_name"], user["last_name"], user["email"], user["phone"], user["password"])) # inserting the user into the database
    db_conn.commit()
    new_user_id = cursor.lastrowid # getting the last row id
    db_conn.close()
    
    return new_user_id, 201 # returning the new user id and the status code = 201 => created

def read_one(user_email):
    GET_USER = "SELECT * FROM users WHERE email = ?"

    db_conn = get_db_connection()
    cursor = db_conn.cursor()
    cursor.execute(GET_USER, (user_email, ) ) # selecting the user by email
    resultset = cursor.fetchall()
    db_conn.close()

    if len(resultset) < 1: # if the resultset is empty
        return "Not found", 404
    elif len(resultset) > 2: # if there are more than 2 results
        return "Too many results found.", 500

    return jsonify(resultset[0]) # returning the user

def read_user_by_id(user_id):
    GET_USER = "SELECT * FROM users WHERE user_id = ?" # selecting the user by id

    db_conn = get_db_connection()
    cursor = db_conn.cursor() # cursor to execute the query
    cursor.execute(GET_USER, (user_id, ) )
    resultset = cursor.fetchall() # fetching the user
    db_conn.close()

    if len(resultset) < 1:
        return "Not found", 404
    elif len(resultset) > 2:
        return "Too many results found.", 500 # if there are more than 2 results, error.

    return jsonify(resultset[0])

def update(user_id, user): # function to update the user
    UPDATE_USER = """
    UPDATE users
    SET first_name = ?,
        last_name = ?,
        email = ?,
        phone = ?
    WHERE user_id = ?
    """

    db_conn = get_db_connection()
    cursor = db_conn.cursor()
    cursor.execute(UPDATE_USER, (user["first_name"], user["last_name"], user["email"], user["phone"], user_id) ) # updating the user
    db_conn.commit()

    return read_one(user_id) # returning the updated user

def delete(user_id):
    DELETE_USER = "DELETE FROM users WHERE user_id=?"

    db_conn = get_db_connection()
    cursor = db_conn.cursor()   # cursor to execute the query
    cursor.execute(DELETE_USER, (user_id, ) )
    db_conn.commit()

    return "Succesfully deleted.", 204 # returning the status code = 204 => no content

# User login (assuming password check is handled elsewhere)
def user_login(credentials):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM users WHERE email=? AND password=?", (credentials["email"], credentials["password"])) # selecting the user by email and password
    row = cur.fetchone()
    if row is None:
        return jsonify({"error": "Invalid Credentials"}), 401 # if the user is not found
    else: # if the user is found
        return row


def user_logout(user_id): # function to logout the user
    return "Logout successful"
