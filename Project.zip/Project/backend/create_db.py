import sqlite3
import sys

from config import CONFIG

# class for creating the database and populating it with sample data
class ExampleDB:
    @staticmethod # static method to initialize the database
    def initialize(database_connection: sqlite3.Connection):
        cursor = database_connection.cursor()  # initialize cursor for database connection
        try:
            print("Dropping existing tables (if present)...")
            cursor.execute("DROP TABLE recipes")
            cursor.execute("DROP TABLE users")
        except sqlite3.OperationalError as db_error: # if there is an error, it will print the error
            print(f"Unable to drop table. Error: {db_error}")
        print("Creating tables...")
        cursor.execute(ExampleDB.CREATE_TABLE_USERS) # creating the table for users
        cursor.execute(ExampleDB.CREATE_TABLE_RECIPES) # creating the table for recipes
        database_connection.commit()

        print("Populating database with sample data...")
        cursor.executemany(ExampleDB.INSERT_USERS, ExampleDB.sample_users)
        cursor.executemany(ExampleDB.INSERT_RECIPES, ExampleDB.sample_recipes)
        database_connection.commit() # commit the changes to the database

    # SQL queries for creating the tables and inserting the sample data
    CREATE_TABLE_USERS = """ 
    CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY NOT NULL,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        phone TEXT,
        password TEXT NOT NULL
    )
    """
    # creating the table for recipes
    CREATE_TABLE_RECIPES = """ 
    CREATE TABLE IF NOT EXISTS recipes (
        recipe_id INTEGER PRIMARY KEY NOT NULL,
        recipe_name TEXT UNIQUE NOT NULL,
        description TEXT,
        created_by INT NOT NULL,
        FOREIGN KEY (created_by) REFERENCES users(user_id) ON DELETE CASCADE 
    )
    """

    INSERT_USERS = "INSERT INTO users VALUES (?, ?, ?, ?, ?, ?)"
    INSERT_RECIPES = "INSERT INTO recipes VALUES (?, ?, ?, ?)"
    
    sample_users = [
        (1, "Ivan", "Blagoev", "ivanb@gmail.com", "+123123123", "password"),
        (2, "Alex", "Petrov", "alexp@mail.com", "+31213123", "123456")
    ]

    sample_recipes = [
        (1, "Pasta", "Tasty Cheese Pasta.", 1),
        (2, "Spicy Rice", "Delicious Spicy Rice.", 1),
        (3, "Chicken Cheese Burger", "Homemade burger with cheese and chicken.", 2),
    ]


def main(): # main function to create the database
    """Execute main function."""
    db_conn = sqlite3.connect(CONFIG["database"]["name"])
    db_conn.row_factory = sqlite3.Row # setting the row factory to sqlite3.Row

    ExampleDB.initialize(db_conn)
    db_conn.close()

    print("Database creation finished!")    

    return 0

if __name__ == "__main__":
    sys.exit( main() )
