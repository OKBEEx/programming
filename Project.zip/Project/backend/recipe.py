import sqlite3
from sqlite3 import Error

# importing the configuration file
from backend.config import CONFIG

def dict_factory(cursor, row): # function to convert the row to a dictionary
    fields = [ column[0] for column in cursor.description ] # getting the column names
    return {key: value for key, value in zip(fields, row)}  # new dictionary with values

def get_db_connection(): # function to get the database connection
    db_conn = sqlite3.connect(CONFIG["database"]["name"])
    db_conn.row_factory = dict_factory
    return db_conn 

# Create a new recipe
def create_recipe(recipe):
    sql = ''' INSERT INTO recipes(recipe_name, description, created_by)
              VALUES(?,?,?) '''
    
    db_conn = get_db_connection()
    cur = db_conn.cursor()
    cur.execute(sql, (recipe['recipe_name'], recipe['description'], recipe['created_by'])) # inserting the recipe into the database
    db_conn.commit() # commit the changes
    db_conn.close()
    return cur.lastrowid # return the last row id

# Get recipe by ID
def get_recipe_by_id(recipe_id):
    db_conn = get_db_connection()
    cur = db_conn.cursor() # cursor to execute the query
    cur.execute("SELECT * FROM recipes WHERE recipe_id=?", (recipe_id,)) # selecting the recipe by id
    row = cur.fetchone() # fetching the row
    return row

# Get recipe by title
def get_recipe_by_title(recipe_title):
    db_conn = get_db_connection()
    cur = db_conn.cursor()
    cur.execute("SELECT * FROM recipes WHERE recipe_name=?", (recipe_title,)) # selecting the recipe by title
    row = cur.fetchone() # fetching the row
    return row

# Delete recipe by title
def delete_recipe_by_id(recipe_id):
    db_conn = get_db_connection()
    sql = 'DELETE FROM recipes WHERE recipe_id=?'
    cur = db_conn.cursor()
    cur.execute(sql, (recipe_id,))
    db_conn.commit()
    return cur.rowcount

# Edit recipe by title
def update_recipe_by_id(recipe_id, recipe):
    db_conn = get_db_connection() 
    # updating the recipe by id
    sql = ''' UPDATE recipes
              SET recipe_name = ?, description = ? 
              WHERE recipe_id = ?'''
    cur = db_conn.cursor()
    cur.execute(sql, (recipe["recipe_name"], recipe["description"], recipe["recipe_id"]))
    db_conn.commit()
    return cur.rowcount

# Get all recipes
def get_all_recipes():
    db_conn = get_db_connection()
    cur = db_conn.cursor()
    cur.execute("SELECT * FROM recipes") # selecting all recipes
    rows = cur.fetchall()
    return rows

# Get recipes by user ID
def get_recipes_by_user(user_id):
    db_conn = get_db_connection()
    cur = db_conn.cursor()
    cur.execute("SELECT * FROM recipes WHERE created_by=?", (user_id,)) # selecting the recipes by user id
    rows = cur.fetchall()
    return rows
