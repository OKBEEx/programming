import connexion # importing connexion library to create the app
from backend.config import CONFIG

# creating the app using connexion
def create_app():
    app = connexion.FlaskApp(__name__)
    app.add_api("recipeApi.yaml") # adding the api specification file
    return app.app

if __name__ == "__main__":
    app = create_app()
    app.run(host=CONFIG["server"]["listen_ip"], port=CONFIG["server"]["port"], debug=CONFIG["server"]["debug"])
