from flask import Flask, render_template, request, make_response, redirect, jsonify, url_for, session
import sys
import os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) # getting the base directory for configuration
print(BASE_DIR)
sys.path.append(BASE_DIR) # adding the base directory to the path
from cli.config import CONFIG
from cli.recipe_api_shim import create_account, user_login, get_recipes_by_user, get_all_recipes, get_recipe_by_id, get_recipe_by_title, delete_recipe_by_id, update_recipe_by_id, create_recipe, get_user_by_email, get_user_by_id
from werkzeug.security import generate_password_hash, check_password_hash
import getpass # for getting the password without echoing it to the console


def AddRecipe(user): # function to add a recipe
    name = input("Give your recipe a Name: ")
    description = input("Describe your recipe: ") # getting the description
    recipe = {
            "recipe_name": name,     # setting the recipe name
            "description": description,     # setting the recipe name and description
            "created_by": user["user_id"] # setting the created by to the user id
        }
    create_recipe(recipe)
    print('Recipe Created Successfully.') # printing the result


def main_menu(user):
    command = input('>> ') # getting the command
    while (command.lower() != 'exit'):
        if command.lower() == 'view-all-recipes': # if the command is view-all-recipes
            recipes = get_all_recipes()
            for recipe in recipes: # for each recipe return the recipe name, description and the user who created it
                created_by_user = get_user_by_id(recipe['created_by'])
                recipe['created_by'] = created_by_user['email'] # setting the created by to the user email
                print(recipe['recipe_id'],'. ', recipe['recipe_name'],', ', recipe['description'],'; Created by: ',recipe['created_by'])
        elif command.lower() == 'view-my-recipes': # if the command is view-my-recipes, get the recipes by the user
            recipes = get_recipes_by_user(user_id=user.get('user_id'))
            for recipe in recipes:
                created_by_user = get_user_by_id(recipe['created_by']) # getting the user who created the recipe
                recipe['created_by'] = created_by_user['email']
                print(recipe['recipe_id'],'. ', recipe['recipe_name'],', ', recipe['description'],'; Created by: ',recipe['created_by'])
        elif command.lower() == 'add-recipe': # if the command is add-recipe call the AddRecipe function
            AddRecipe(user)
        command = input('>> ') # getting the command again

def Login(email):
    print('Enter Password: ')
    password = input('>> ')
    response = user_login({'email': email, 'password': password}) # login the user with the email and password
    if response is None:
        print("\nIncorrect Credentials. Please try again. \nEnter Email: ")
        email = input()
        if email.lower() == 'exit': # if the user enters exit, exit the program
            sys.exit()
        Login(email=email)
    else:
        print('Logged In successfully. Kindly input commands now:') # if the user is logged in successfully, print the message
        main_menu(response) # call the main menu function with the user as the argument


def Signup():
    while(True): # while loop to get the user details
        try:
            email = input("Enter your Email: ")
            if email.lower() == 'exit': # if the user enters exit, exit the program 
                sys.exit()
            first = input("Enter First Name: ") # getting the first name
            last = input("Enter Last Name: ")
            phone = input("Enter Phone Number: ")
            password = getpass.getpass() # getting the password without echoing it to the console
            confirm_password = getpass.getpass()
            if password != confirm_password: # if the passwords don't match, print the message
                print("Both passwords doesn't match. Please try again.")
            else:
                create_account(first, last, email, phone, password)
                break # break the loop if the user is created successfully and the passwords match
        except Exception as e:
            print('Error: ', e, '\nPlease Try Again.')

    print('Signed up successfully. Kindly Login now:')
    print('Enter Email Address: ')
    email_address = input('>> ')
    if email_address.lower() == 'exit': # if the user enters exit, exit the program
        sys.exit()
    Login(email_address) # login the user with the email address

def main():
    print('\nWelcome to Command Line tool for Recipe App (Enter "exit" to exit the app). \nYou need to login first (Enter "signup" if you want to signup): \nEnter Email:')
    email = input('>> ') # getting the email address from the user to login
    if email.lower() == 'exit':
        sys.exit()
    elif email.lower() == 'signup': # if the user enters signup, call the Signup function
        Signup()
    else:
        Login(email) # login the user with the email address

if __name__ == '__main__': 
    main()  # call the main function