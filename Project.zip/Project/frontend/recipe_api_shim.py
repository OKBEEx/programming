import requests
import json

from frontend.config import CONFIG

BASE_URL = CONFIG['api']['url'] # api url from config file

def create_recipe(recipe_data):
    url = f"{BASE_URL}/recipes/create_recipe"
    response = requests.post(url, json=recipe_data) # post request to create a recipe, the data is stored in dict.
    return response.json() if response.status_code == 201 else response.status_code  # if the status code is 201, the recipe was created successfully.

def get_recipe_by_id(recipe_id):
    url = f"{BASE_URL}/recipes/{recipe_id}"
    print(f"Requesting URL: {url}")  # Debugging statement
    response = requests.get(url) # get request = retrieve data from the server (recipe id)
    
    if response.status_code == 200:
        return response.json()
    else:
        print(f"Error: {response.status_code}, Response: {response.text}")  # Debugging statement
        return response.status_code

def get_recipe_by_title(recipe_title):
    url = f"{BASE_URL}/recipes/{recipe_title}"
    response = requests.get(url) # get request = retrieve data from the server (recipe title)
    return response.json() if response.status_code == 200 else response.status_code

def delete_recipe_by_id(recipe_id):
    url = f"{BASE_URL}/recipes/{recipe_id}"
    response = requests.delete(url) # delete request = removing data from the server by recipe id
    return response.status_code

def update_recipe_by_id(recipe_id, recipe_data):
    url = f"{BASE_URL}/recipes/{recipe_id}"
    response = requests.put(url, json=recipe_data) # put request = updating data 
    return response.json() if response.status_code == 200 else response.status_code

def get_all_recipes():
    url = f"{BASE_URL}/recipes"
    response = requests.get(url) # retrieving every recipe from the server
    return response.json()

def get_recipes_by_user(user_id):
    url = f"{BASE_URL}/recipes/user/{user_id}"
    response = requests.get(url) # returns information about the user's recipes
    return response.json() if response.status_code == 200 else response.status_code # if status code is 200 => good, otherwise => bad

def create_account(first_name, last_name, email, phone, password):
    # needs arguments to create a new user
    new_user = {
        "first_name": first_name,
        "last_name": last_name,
        "email": email,
        "phone": phone,
        "password": password
    }
    url = f"{BASE_URL}/account/signup"
    response = requests.post(url, json=new_user) # post request => creating information about the user
    return response.status_code

def user_login(credentials):
    url = f"{BASE_URL}/account/login"
    response = requests.post(url, json=credentials) # post request => logging in the user
    return response.json() if response.status_code == 200 else None # status code == 200 => good, otherwise => None

def get_user_by_email(user_email):
    # returns user information by email
    url = f"{BASE_URL}/account/profile/{user_email}"
    response = requests.get(url)
    
    if response.status_code == 200:
        return response.json()
    else:
        print(f"Error: {response.status_code}, Response: {response.text}")  # Debugging statement
        return response.status_code
    
def get_user_by_id(user_id): # returns user information by id
    url = f"{BASE_URL}/account/profile/id/{user_id}"
    response = requests.get(url) # get request => retrieving data from the server
    
    if response.status_code == 200:
        return response.json()
    else:
        print(f"Error: {response.status_code}, Response: {response.text}")  # Debugging statement
        return response.status_code
 