from flask import Flask, render_template, request, make_response, redirect, jsonify, url_for, session

import sys
import os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) # getting the base directory
print(BASE_DIR)
sys.path.append(BASE_DIR) # adding the path to the sys path

from frontend.config import CONFIG
from frontend.recipe_api_shim import create_account, user_login, get_recipes_by_user, get_all_recipes, get_recipe_by_id, get_recipe_by_title, delete_recipe_by_id, update_recipe_by_id, create_recipe, get_user_by_email, get_user_by_id
from werkzeug.security import generate_password_hash, check_password_hash


app = Flask(__name__) # creating a flask app
app.secret_key = 'mysecretkey' # secret key for session
 

@app.route("/")
def homepage():
    user_email = session.get('loggedin_user', None) # getting the session key
    if user_email is None:
        return redirect(url_for('login'))
    
    #retrieves all recipes and the current's user recipes when its logged in.
    user = get_user_by_email(user_email)
    user_id = user["user_id"]
    all_recipes = get_all_recipes() # gets all recipes from the server
    my_recipes = get_recipes_by_user(user_id) # gets the recipes created by the current user

    for recipe in all_recipes:
        created_by_user = get_user_by_id(recipe['created_by'])
        recipe['created_by'] = created_by_user['email'] # getting the email of the user who created the recipe

    return render_template("main.html", recipes=all_recipes, my_recipes=my_recipes)

# returns the recipes created by the current user in his profile
@app.route("/profile")
def profile():
    user_email = session.get('loggedin_user', None) # getting the session key
    if user_email is None:
        return redirect('login')
    user = get_user_by_email(user_email) # getting the user by email
    user_id = user["user_id"] # getting the id of the user
    my_recipes=get_recipes_by_user(user_id) # getting the recipes created by the user

    return render_template("profile.html", my_recipes=my_recipes, user=user)


@app.route("/signup/", methods=["GET", "POST"])
def signup():
    if request.method == "GET": #if the request is get, it will render the signup.html
        return render_template("signup.html")
    elif request.method == "POST":
        user = {} #creating a user object
        user["first_name"] = request.form["first_name"]
        user["last_name"] = request.form["last_name"]
        user["email"] = request.form["email"]
        user["phone"] = request.form["phone"]
        user["password"] = generate_password_hash(password=request.form["password"], method="sha256")
        user["user_id"] = create_account(user["first_name"], user["last_name"], user["email"], user["phone"], user["password"])
        session['loggedin_user'] = user["email"] #setting session key when signed up
        return redirect(url_for('homepage'))

    return make_response("Invalid request", 400)


@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get('loggedin_user', None) is not None: # if the user is already logged in, it will redirect to the homepage
        return redirect(url_for('homepage'))
    
    if request.method == "GET":
        return render_template("login.html")
    elif request.method == "POST":
        #authencation of user / credentials
        email = request.form["email"]
        password = request.form["password"]
        hashed_password = generate_password_hash(password=password, method="sha256")
        credentials = {'email': email, 'password': password} #creating credentials object
        authenticated_user = user_login(credentials=credentials)
        if authenticated_user is None:
            return render_template('login.html', email=email) #if user is not authenticated, it will return to login page
        session['loggedin_user'] = email # setting session key when logged in
        return redirect(url_for('homepage'))

    return make_response("Invalid request", 400)


@app.route("/logout", methods=["GET", "POST"])
def logout():
    session.pop('loggedin_user', None) #removing session key when logged out
    return redirect(url_for('login'))


@app.route("/delete-recipe/<int:id>")
def deleteRecipe(id):
    delete_recipe_by_id(id) # deletes the recipe by id
    return redirect("/")


@app.route("/edit-recipe/<int:recipe_id>", methods=["GET", "POST"])
def editRecipe(recipe_id):
    #editing the recipe by id
    if request.method == "GET":
        recipe = get_recipe_by_id(recipe_id)
        return render_template("edit_recipe.html", recipe=recipe)
    elif request.method == "POST":
        # based on the new inout, it will update the recipe
        recipe = {
            "recipe_id": recipe_id,
            "recipe_name": request.form["name"],
            "description":  request.form["desc"]
        }
        update_recipe_by_id(recipe_id, recipe) # updates recipe in the server
        return redirect(url_for('homepage'))
    
    return make_response("Inalid request", 400)


@app.route("/add-recipe", methods=["GET", "POST"])
def addRecipe():
    if request.method == "GET": #if the request is get, it will render the add_recipe.html
        return render_template("add_recipe.html")
    elif request.method == "POST":
        #creating recipe based on the input
        user_email = session.get('loggedin_user', None)
        user = get_user_by_email(user_email)
        recipe = {
            "recipe_name": request.form["name"],
            "description": request.form["desc"],
            "created_by": user["user_id"]
        }
        create_recipe(recipe) # creates recipe in the server
        return redirect(url_for('homepage'))
    
    return make_response("Inalid request", 400)

 
if __name__ == "__main__": # starting/running the frontend server
    app.run(host=CONFIG["frontend"]["listen_ip"], port=CONFIG["frontend"]["port"], debug=CONFIG["frontend"]["debug"])
